const UrlService = require('./UrlService');
const urlService = new UrlService();

// Singleton
module.exports = urlService;
